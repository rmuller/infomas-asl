<#assign licensePrefix = " * ">
/* ${nameAndExt}
 *
 * Created: ${date?date?string("yyyy-MM-dd")} (Year-Month-Day)
 * Character encoding: ${encoding}
 *
 ****************************************** LICENSE *******************************************
 *
<#include "../Licenses/license-${project.license}.txt">
 */
<#if package?? && package != "">
package ${package};

</#if>
import eu.infomas.logging.Logger;
import eu.infomas.logging.LoggerFactory;

/**
 * {@code ${name}}.
 *
 * @author ${user}
 * @since INFOMAS NG 3.0
 */
public class ${name} {

    private final static Logger LOG = LoggerFactory.getLogger(${name}.class);

}
