<#if package?? && package != "">
package ${package};

</#if>
<#if methodTearDown!false>
import org.junit.After;
</#if>
<#if classTearDown!false>
import org.junit.AfterClass;
</#if>
<#if methodSetUp!false>
import org.junit.Before;
</#if>
<#if classSetUp!false>
import org.junit.BeforeClass;
</#if>
import org.junit.Test;

import eu.infomas.logging.Logger;
import eu.infomas.logging.LoggerFactory;

import static org.junit.Assert.*;

public final class ${name} {

    private final static Logger LOG = LoggerFactory.getLogger();

    @Test
    public void test() {
    }

}